# setup.py
from setuptools import setup

setup(
    name='hw2',
    version='1.0.0',
    packages=['hw2'],
)