# Installation guide

HW2 has the same requirements as HW1, so if you have followed the installation [guide](../hw1/installation.md) for HW1, you are almost set up!

Additionally, you only need to install hw2 codebase as a development package `hw2`:

```bash
cd <path_to_hw2>
pip install -e .
```
